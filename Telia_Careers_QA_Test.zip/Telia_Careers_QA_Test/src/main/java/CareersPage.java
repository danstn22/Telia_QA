import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CareersPage extends BasePage {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    BasePage basePage;

    public CareersPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = ".btn.btn-tertiary.btn--light")
    private WebElement jobOffers;

    @FindBy(css = "input[data-testid='search-input']")
    private WebElement jobSearchField;

    @FindBy(css = "div[data-testid='job-list-item-desktop']")
    private WebElement positiveJobSearchResult;

    @FindBy(xpath = "//telia-heading[@class=\"telia-heading--undefined hydrated\"]")
    private WebElement negativeJobSearchResult;


    public void clickJobOffers() {
        jobOffers.click();
    }

    public void clickAcceptAllCookies() {
        WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Accept All']")));
        acceptCookies.click();
    }

    public void setJobSearchField(String job) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(jobSearchField));  // Laukti, kol elementas bus paspaudžiamas
        element.sendKeys(job);  // Paspaudžiamas elementas
        element.sendKeys(Keys.ENTER);
    }

    public String getJobSearchResult() {
        try {
            // Laukiame, kol "positiveJobSearchResult" bus matomas
            wait.until(ExpectedConditions.visibilityOf(positiveJobSearchResult));
            return positiveJobSearchResult.getText();
        } catch (TimeoutException e) {
            // Jei "positiveJobSearchResult" nepasirodo per laukimo laiką
        }

        try {
            // Laukiame, kol "negativeJobSearchResult" bus matomas
            wait.until(ExpectedConditions.visibilityOf(negativeJobSearchResult));
            return negativeJobSearchResult.getText();
        } catch (TimeoutException e) {
            // Jei "negativeJobSearchResult" nepasirodo per laukimo laiką
        }

        return "No job search result available.";
    }
}