
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.time.Duration;

public class SearchPage extends BasePage {
    public SearchPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = "button[aria-label='Globali paieška Telia svetainėje']")
    private WebElement searchIcon;

    @FindBy(css = "input[aria-label='Paieškos rezultatai bus rodomi žemiau']")
    private WebElement searchField;

    @FindBy(xpath = "//button[normalize-space()='Kita']")
    private WebElement anotherSelection;

    @FindBy(css = "a[href*='/karjera']")
    private WebElement careersPage;


    public void clickSearchIcon() {
        searchIcon.click();
    }

    public void setSearchField(String search) {
        searchField.sendKeys(search);
        searchField.sendKeys(Keys.ENTER);
    }

    public void clickAnotherSelection() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));  // Laukti iki 10 sekundžių
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(anotherSelection));  // Laukti, kol elementas bus paspaudžiamas
        element.click();  // Paspaudžiamas elementas
    }

    public void clickCareersPage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(careersPage));
        element.click();
    }

}
