
import handlers.WindowHandlers;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class SearchTest extends Base {
    SearchPage searchPage;
    BasePage basePage;
    CareersPage careersPage;
    WindowHandlers windowHandlers;


    @ParameterizedTest
    @CsvSource(value = {"karjera,Inžinierius", "karjera,Salono konsultantas", "karjera,Testuotojas"})
    void careersSearchFunctionalityTest(String searchText, String job) {
        searchPage = new SearchPage(driver);
        basePage = new BasePage(driver);
        careersPage = new CareersPage(driver);
        windowHandlers = new WindowHandlers(driver);

        searchPage.clickSearchIcon();
        searchPage.setSearchField(searchText);
        searchPage.clickAnotherSelection();
        searchPage.clickCareersPage();

        careersPage.clickJobOffers();
        windowHandlers.switchToNewWindow();
        careersPage.clickAcceptAllCookies();
        careersPage.setJobSearchField(job);
        //Assertions
        Assertions.assertThat(careersPage.getJobSearchResult()).contains(job);

    }
}
